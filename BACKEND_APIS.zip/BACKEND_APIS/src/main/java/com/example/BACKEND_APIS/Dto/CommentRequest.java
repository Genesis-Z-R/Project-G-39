package com.example.BACKEND_APIS.Dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class CommentRequest {
    private String content;
}
