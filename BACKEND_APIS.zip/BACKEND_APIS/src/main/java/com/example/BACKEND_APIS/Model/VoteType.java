package com.example.BACKEND_APIS.Model;

public enum VoteType {
    UPVOTE,
    DOWNVOTE
}
