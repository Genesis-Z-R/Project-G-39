package com.example.BACKEND_APIS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendApisApplicationTests {

	@Test
	void contextLoads() {
	}

}
